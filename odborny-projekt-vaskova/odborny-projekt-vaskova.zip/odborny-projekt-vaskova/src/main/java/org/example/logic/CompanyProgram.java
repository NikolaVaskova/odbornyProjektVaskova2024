package org.example.logic;

import org.example.graphic.Graphics;

public class CompanyProgram {
    public static void main(String[] args) {
        new Graphics();
    }
}