package org.example.graphic;

import javax.swing.*;
import java.awt.*;
public class Graphics extends JFrame {
    public Graphics()throws HeadlessException{
        new Login();
    }
}