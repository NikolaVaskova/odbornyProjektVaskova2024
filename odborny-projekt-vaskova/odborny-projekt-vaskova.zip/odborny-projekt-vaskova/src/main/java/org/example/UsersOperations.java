package org.example;

public enum UsersOperations {
    NEW_USER
}
