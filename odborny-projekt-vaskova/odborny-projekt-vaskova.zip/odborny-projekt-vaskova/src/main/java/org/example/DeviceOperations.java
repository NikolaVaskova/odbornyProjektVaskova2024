package org.example;

public enum DeviceOperations {
    NEW_PC, SCRAPED_PC, STORED_PC
}
